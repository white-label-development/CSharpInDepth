﻿namespace TennisBookings.Web.Domain
{
    public class CurrentWeatherResult
    {
        public string Description { get; set; }
    }
}
