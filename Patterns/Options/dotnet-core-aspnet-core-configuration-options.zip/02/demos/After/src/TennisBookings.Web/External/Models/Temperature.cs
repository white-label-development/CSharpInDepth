﻿namespace TennisBookings.Web.External.Models
{
    public class Temperature
    {
        public float Min { get; set; }
        public float Max { get; set; }
    }
}
