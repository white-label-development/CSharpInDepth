﻿using TechTalk.SpecFlow;

namespace GameCore.Specs
{
    [Binding]
    [Scope(Tag = "awaitingReviewBeforeStartingWork")]
    public class AwaitingReviewSteps
    {
        [Given(".*")]
        [When(".*")]
        [Then(".*")]
        public void Empty()
        {

        }

    }
}
