﻿namespace GameCore
{
    public enum CharacterClass
    {
        None,
        Healer,
        Warrior
    }
}
