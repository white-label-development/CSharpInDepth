﻿namespace GameCore
{
    public class Weapon
    {
        public string Name { get; set; }
        public int Value { get; set; }
    }
}
