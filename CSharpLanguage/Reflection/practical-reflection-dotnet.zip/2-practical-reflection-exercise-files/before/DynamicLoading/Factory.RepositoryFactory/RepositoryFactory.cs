﻿using PersonRepository.Interface;
using System;
using System.Configuration;

namespace Factory.RepositoryFactory
{
    public static class RepositoryFactory
    {
        public static IPersonRepository GetPersonRepository()
        {
            throw new NotImplementedException();
        }
    }
}
